package developer.ahmad.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.NumberFormat;

public class MainActivity extends AppCompatActivity {


    private Button btnPercentage, btnPower, btnRoot, btnDivide, btn7, btn8, btn9, btnMultiple, btn4, btn5, btn6, btnMinus, btn1, btn2, btn3, btn_plus, btn0, btnDecimal, btnRemove, btnEqual, btnword;

    private EditText addItem;
    private TextView wordable;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();

    }
    private void init() {

        bindViews();
        btnPercentage.setOnClickListener(v -> {
            String value = addItem.getText().toString();
            if (!value.isEmpty()) {
                double b = Double.parseDouble(value) / 100;
                addItem.setText(String.valueOf(b));
            } else {
                addItem.setText("");
            }
        });

        btnPower.setOnClickListener(v -> {
            String value = addItem.getText().toString();
            try {
            if (!value.isEmpty()) {
                double power = Math.pow(Double.parseDouble(addItem.getText().toString()), 2);
                addItem.setText(String.valueOf(power));
            } else {
                addItem.setText("");

            }

            } catch (NumberFormatException e) {
                throw new RuntimeException(e);
            }
        });

        btnRoot.setOnClickListener(v -> {
            String value = addItem.getText().toString();
            try {
                if (!value.isEmpty()) {
                    double squareRoot = Math.sqrt(Double.parseDouble(addItem.getText().toString()));
                    addItem.setText(String.valueOf(squareRoot));
                } else {
                    addItem.setText("");
                }
            } catch (NumberFormatException e) {
                throw new RuntimeException(e);
            }

        });

        btnDivide.setOnClickListener(v -> {
            String value = addItem.getText().toString();
            if (!value.isEmpty()) {
                addItem.setText(addItem.getText() + "/");
            } else {
                addItem.setText("");
            }

        });

        btnMultiple.setOnClickListener(v -> {
            String value = addItem.getText().toString();
            if (!value.isEmpty()) {
                addItem.setText(addItem.getText() + "*");
            } else {
                addItem.setText("");
            }

        });
        btnMinus.setOnClickListener(v -> {
            String value = addItem.getText().toString();
            if (!value.isEmpty()) {
                addItem.setText(addItem.getText() + "-");

            } else {
                addItem.setText("");
            }
        });

        btn_plus.setOnClickListener(v -> {
            String value = addItem.getText().toString();
            if (!value.isEmpty()) {
                addItem.setText(addItem.getText() + "+");
            } else {
                addItem.setText("");
            }

        });

        btnDecimal.setOnClickListener(v -> {
            String value = addItem.getText().toString();
            if (!value.isEmpty()) {
                addItem.setText(addItem.getText() + ".");
            } else {
                addItem.setText("");
            }
        });

        btnRemove.setOnClickListener(v -> {
            String currentValue = addItem.getText().toString();
            if (!currentValue.isEmpty()) {
                addItem.setText(currentValue.substring(0, currentValue.length() - 1));
            } else {
                addItem.setText("");
            }
        });

        btnEqual.setOnClickListener(v -> {
            String val = addItem.getText().toString();
            if (!val.isEmpty()) {
                try {
                    String replacedstr = val.replace('÷', '/').replace('×', '*');
                    double result = eval(replacedstr);
                    addItem.setText(String.valueOf(result));
                } catch (Exception E) {
                    E.getMessage();
                }
            } else {
                addItem.setText("");
            }

        });
        btn0.setOnClickListener(v -> addItem.setText(addItem.getText() + "0"));
        btn1.setOnClickListener(v -> addItem.setText(addItem.getText() + "1"));
        btn2.setOnClickListener(v -> addItem.setText(addItem.getText() + "2"));
        btn3.setOnClickListener(v -> addItem.setText(addItem.getText() + "3"));
        btn4.setOnClickListener(v -> addItem.setText(addItem.getText() + "4"));
        btn5.setOnClickListener(v -> addItem.setText(addItem.getText() + "5"));
        btn6.setOnClickListener(v -> addItem.setText(addItem.getText() + "6"));
        btn7.setOnClickListener(v -> addItem.setText(addItem.getText() + "7"));
        btn8.setOnClickListener(v -> addItem.setText(addItem.getText() + "8"));
        btn9.setOnClickListener(v -> addItem.setText(addItem.getText() + "9"));

        try {
            btnword.setOnClickListener(v -> {
                String L = addItem.getText().toString();
                if (!L.isEmpty()) {
                    String result = convert(Double.parseDouble(L));
                    wordable.setText(result);
                } else {
                    addItem.setText("");
                }
            });

        } catch (Exception E) {
            E.getMessage();
        }

    }

    private void bindViews() {
        btnPercentage = findViewById(R.id.percent);
        btnPower = findViewById(R.id.power);
        btnRoot = findViewById(R.id.squareـroot);
        btnDivide = findViewById(R.id.divide);
        btn7 = findViewById(R.id.seven);
        btn8 = findViewById(R.id.eight);
        btn9 = findViewById(R.id.nine);
        btnMultiple = findViewById(R.id.multiple);
        btn4 = findViewById(R.id.four);
        btn5 = findViewById(R.id.five);
        btn6 = findViewById(R.id.six);
        btnMinus = findViewById(R.id.minus);
        btn1 = findViewById(R.id.one);
        btn2 = findViewById(R.id.two);
        btn3 = findViewById(R.id.three);
        btn_plus = findViewById(R.id.plus);
        btn0 = findViewById(R.id.zero);
        btnDecimal = findViewById(R.id.decimal);
        btnRemove = findViewById(R.id.remove);
        btnEqual = findViewById(R.id.equal);
        btnword = findViewById(R.id.btn_change_to_word);
        addItem = findViewById(R.id.add_item);
        wordable = findViewById(R.id.change_to_word);


    }


    //eval function
    public static double eval(final String str) {
        return new Object() {
            int pos = -1, ch;

            void nextChar() {
                ch = (++pos < str.length()) ? str.charAt(pos) : -1;
            }

            boolean eat(int charToEat) {
                while (ch == ' ') nextChar();
                if (ch == charToEat) {
                    nextChar();
                    return true;
                }
                return false;
            }

            double parse() {
                nextChar();
                double x = parseExpression();
                if (pos < str.length()) throw new RuntimeException("Unexpected: " + (char) ch);
                return x;
            }

            // Grammar:
            // expression = term | expression `+` term | expression `-` term
            // term = factor | term `*` factor | term `/` factor
            // factor = `+` factor | `-` factor | `(` expression `)`
            //        | number | functionName factor | factor `^` factor

            double parseExpression() {
                double x = parseTerm();
                for (; ; ) {
                    if (eat('+')) x += parseTerm(); // addition
                    else if (eat('-')) x -= parseTerm(); // subtraction
                    else return x;
                }
            }

            double parseTerm() {
                double x = parseFactor();
                for (; ; ) {
                    if (eat('*')) x *= parseFactor(); // multiplication
                    else if (eat('/')) x /= parseFactor(); // division
                    else return x;
                }
            }

            double parseFactor() {
                if (eat('+')) return parseFactor(); // unary plus
                if (eat('-')) return -parseFactor(); // unary minus

                double x;
                int startPos = this.pos;
                if (eat('(')) { // parentheses
                    x = parseExpression();
                    eat(')');
                } else if ((ch >= '0' && ch <= '9') || ch == '.') { // numbers
                    while ((ch >= '0' && ch <= '9') || ch == '.') nextChar();
                    x = Double.parseDouble(str.substring(startPos, this.pos));
                } else if (ch >= 'a' && ch <= 'z') { // functions
                    while (ch >= 'a' && ch <= 'z') nextChar();
                    String func = str.substring(startPos, this.pos);
                    x = parseFactor();
                    if (func.equals("sqrt")) x = Math.sqrt(x);
                    else if (func.equals("sin")) x = Math.sin(Math.toRadians(x));
                    else if (func.equals("cos")) x = Math.cos(Math.toRadians(x));
                    else if (func.equals("tan")) x = Math.tan(Math.toRadians(x));
                    else if (func.equals("log")) x = Math.log10(x);
                    else if (func.equals("ln")) x = Math.log(x);
                    else throw new RuntimeException("Unknown function: " + func);
                } else {
                    throw new RuntimeException("Unexpected: " + (char) ch);
                }

                if (eat('^')) x = Math.pow(x, parseFactor()); // exponentiation

                return x;
            }
        }.parse();
    }

    public static String convert(double number) {
        final String[] UNITS = {"zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen"};
        final String[] TENS = {"", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"};

        if (number < 0) {
            throw new IllegalArgumentException("Number cannot be negative");
        }
        if (number < 20) {
            return UNITS[(int) number];
        }
        if (number < 100) {
            return TENS[(int) (number / 10)] + ((number % 10 != 0) ? " " : "") + UNITS[(int) (number % 10)];
        }
        if (number < 1000) {
            return UNITS[(int) (number / 100)] + " hundred" + ((number % 100 != 0) ? " and " : "") + convert(number % 100);
        }
        if (number < 1000000) {
            return convert(number / 1000) + " thousand" + ((number % 1000 != 0) ? " " : "") + convert(number % 1000);
        }
        if (number < 1000000000) {
            return convert(number / 1000000) + " million" + ((number % 1000000 != 0) ? " " : "") + convert(number % 1000000);
        }
        return "Number too large";
    }

    public static Double stringToDouble(String s) throws NumberFormatException {
        double num = 0;
        for (int i = 0; i < s.length(); i++) {
            if (((double) s.charAt(i) >= 48) && ((double) s.charAt(i) <= 59)) {
                num = num * 10 + ((double) s.charAt(i) - 48);
            } else {
                throw new NumberFormatException();
            }

        }
        return num;
    }
}












                
            
        



