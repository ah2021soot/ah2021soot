package developer.ahmad.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;

public class SientificActivity extends AppCompatActivity {
    private Button parantez1,parantez2,MC,Mplus,Mminus,MR,AC,NEG_POS,Percentage,Substance,
    Power2,Power3,Power,Pword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sientific);
    }


    /*

























                    <Button
                        android:id="@+id/p_word"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="e^x"
                        android:layout_margin="3dp"></Button>

                    <Button
                        android:id="@+id/unknown_ten_power"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="10^x"
                        android:textSize="12dp"
                        android:layout_margin="3dp"></Button>

                    <Button
                        android:id="@+id/seven"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="7"
                        android:layout_margin="3dp"></Button>

                    <Button
                        android:id="@+id/eight"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="8"
                        android:layout_margin="3dp"></Button>

                    <Button
                        android:id="@+id/nine"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="9"
                        android:layout_margin="3dp"></Button>

                    <Button
                        android:id="@+id/multiple"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="*"
                        android:layout_margin="3dp"></Button>
                </TableRow>

                <TableRow
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content">

                    <Button
                        android:id="@+id/upside"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="1/x"
                        android:layout_margin="3dp"></Button>

                    <Button
                        android:id="@+id/root_two"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="√"
                        android:layout_margin="3dp"></Button>

                    <Button
                        android:id="@+id/root_three"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="3√"
                        android:layout_margin="3dp"></Button>

                    <Button
                        android:id="@+id/unknown_x_root"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="x√y"
                        android:layout_margin="3dp"></Button>

                    <Button
                        android:id="@+id/ln"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="ln"
                        android:layout_margin="3dp"></Button>

                    <Button
                        android:id="@+id/log"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="log"
                        android:layout_margin="3dp"></Button>

                    <Button
                        android:id="@+id/four"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="4"
                        android:layout_margin="3dp"></Button>

                    <Button
                        android:id="@+id/five"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="5"
                        android:layout_margin="3dp"></Button>

                    <Button
                        android:id="@+id/six"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="6"
                        android:layout_margin="3dp"></Button>

                    <Button
                        android:id="@+id/minus"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="-"
                        android:layout_margin="3dp"></Button>
                </TableRow>

                <TableRow
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content">

                    <Button
                        android:id="@+id/factoriel"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="x!"
                        android:layout_margin="3dp"></Button>

                    <Button
                        android:id="@+id/sinus"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="sin"
                        android:layout_margin="3dp"></Button>

                    <Button
                        android:id="@+id/cosinus"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="cos"
                        android:layout_margin="3dp"></Button>

                    <Button
                        android:id="@+id/tanjant"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="tan"
                        android:layout_margin="3dp"></Button>

                    <Button
                      android:id="@+id/cot"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="cot"
                        android:layout_margin="3dp"></Button>

                    <Button
                        android:id="@+id/eNumber"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="e"
                        android:layout_margin="3dp"></Button>

                    <Button
                        android:id="@+id/one"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="1"
                        android:layout_margin="3dp"></Button>

                    <Button
                        android:id="@+id/two"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="2"
                        android:layout_margin="3dp"></Button>

                    <Button
                        android:id="@+id/three"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="3"
                        android:layout_margin="3dp"></Button>

                    <Button
                        android:id="@+id/plus"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="+"
                        android:layout_margin="3dp"></Button>
                </TableRow>

                <TableRow
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content">

                    <Button
                        android:id="@+id/radian"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="RAD"
                        android:layout_margin="3dp"></Button>

                    <Button
                        android:id="@+id/sinh"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="@string/sinh"
                        android:textSize="12sp"
                        android:layout_margin="3dp"></Button>

                    <Button
                        android:id="@+id/cosh"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:textSize="10sp"
                        android:text="@string/cosh"
                        android:layout_margin="3dp"></Button>

                    <Button
                        android:id="@+id/tanh"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="@string/tanh"
                        android:textSize="10sp"
                        android:layout_margin="3dp"></Button>

                    <Button
                        android:id="@+id/coth"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="@string/coth"
                        android:textSize="10sp"
                        android:layout_margin="3dp"></Button>

                    <Button
                        android:id="@+id/pi"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="π"
                        android:layout_margin="3dp"></Button>

                    <Button
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:layout_margin="3dp"></Button>



                        <Button
                            android:id="@+id/zero"
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="0"
                            android:layout_margin="3dp"></Button>

                    <Button
                        android:id="@+id/dot"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="."
                        android:layout_margin="3dp"></Button>


                    <Button
                        android:id="@+id/equal"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="="
                        android:layout_margin="3dp"></Button>
                </TableRow>

            </TableLayout>

        </LinearLayout>
</LinearLayout>*/



}